package com.example;
//add() : Este método se utiliza para agregar un elemento a una colección o estructura de datos. La implementación específica del método puede variar según el tipo de colección. Por ejemplo, en una lista, el método add()agrega un elemento al final de la lista. En un conjunto, agregue un elemento al conjunto si aún no está presente.

//remove() : El método remove()se utiliza para eliminar un elemento específico de una colección. Nuevamente, la implementación variará según el tipo de colección. En una lista, se eliminará el elemento especificado si está presente. En un conjunto, se eliminará el elemento si está en el conjunto.

//get() : El método get()se utiliza para obtener un elemento de una colección en función de su posición o clave, dependiendo del tipo de colección. Por ejemplo, en una lista, se proporciona un índice y se obtiene el elemento en esa posición. En un diccionario o mapa, se proporciona una clave y se obtiene el valor asociado a esa clave.

//set() : El método set()se utiliza para modificar el valor de un elemento en una colección en función de su posición o clave. Nuevamente, la implementación varía según el tipo de colección. En una lista, se proporciona un índice y un nuevo valor, y se actualiza el elemento en esa posición. En un diccionario, se proporciona una clave y un nuevo valor, y se actualiza el valor asociado a esa clave.

//size() : El método size()se utiliza para obtener el número de elementos en una colección. Esto proporciona la cantidad total de elementos en la colección, lo que es útil para conocer su longitud o tamaño.

//isEmpty() : El método isEmpty()se utiliza para verificar si una colección está vacía, es decir, si no contiene ningún elemento. Devuelve un valor booleano, por lo que normalmente se utiliza en una condición para verificar si una colección está vacía o no.
