package com.example;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        
        ArrayList<Integer> numeros = new ArrayList<Integer>();

        
        numeros.add(10);
        numeros.add(20);
        numeros.add(30);
        numeros.add(40);
        numeros.add(50);

       
        if (numeros.size() >= 3) {
            
            int tercerElemento = numeros.get(2);
            System.out.println("El tercer elemento de la lista es: " + tercerElemento);
        } else {
            System.out.println("La lista no tiene al menos 3 elementos.");
        }
    }
}

