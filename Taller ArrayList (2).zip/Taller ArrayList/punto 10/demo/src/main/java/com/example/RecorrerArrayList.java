package com.example;

import java.util.ArrayList;

public class RecorrerArrayList {
    public static void main(String[] args) {
        ArrayList<Integer> numeros = new ArrayList<Integer>();

        
        numeros.add(1);
        numeros.add(2);
        numeros.add(3);
        numeros.add(4);
        numeros.add(5);

    
        for (int numero : numeros) {
            System.out.println(numero);
        }
    }
}
