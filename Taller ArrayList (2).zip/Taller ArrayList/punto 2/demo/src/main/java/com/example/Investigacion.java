package com.example;

import java.util.ArrayList;

public class Investigacion {
    public static void main(String[] args) {
       
        ArrayList<String> miArrayList = new ArrayList<>();

        
        boolean estaVacia = miArrayList.isEmpty();

        
        if (estaVacia) {
            System.out.println("La lista está vacía.");
        } else {
            System.out.println("La lista no está vacía.");
        }

        
        miArrayList.add("Manzana");
        miArrayList.add("Banana");
        miArrayList.add("Cereza");

       
        estaVacia = miArrayList.isEmpty();

        if (estaVacia) {
            System.out.println("La lista está vacía.");
        } else {
            System.out.println("La lista no está vacía.");
        }
    }
}

