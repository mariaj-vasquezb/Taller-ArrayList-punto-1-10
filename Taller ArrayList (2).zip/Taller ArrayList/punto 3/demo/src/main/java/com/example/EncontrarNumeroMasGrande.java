package com.example;

import java.util.ArrayList;

public class EncontrarNumeroMasGrande {
    public static void main(String[] args) {
        ArrayList<Integer> numeros = new ArrayList<Integer>();

        
        numeros.add(25);
        numeros.add(10);
        numeros.add(56);
        numeros.add(42);
        numeros.add(78);
        numeros.add(31);

        int numeroMasGrande = numeros.get(0);

        
        for (int numero : numeros) {
            if (numero > numeroMasGrande) {
                numeroMasGrande = numero;
            }
        }

        System.out.println("El número más grande es: " + numeroMasGrande);
    }
}
