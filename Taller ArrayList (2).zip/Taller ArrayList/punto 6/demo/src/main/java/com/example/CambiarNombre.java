package com.example;
import java.util.ArrayList;

public class CambiarNombre {
    public static void main(String[] args) {
        ArrayList<String> nombres = new ArrayList<String>();


        nombres.add("Camilo");
        nombres.add("María");
        nombres.add("Pedro");
        nombres.add("Santiago");

        
        if (nombres.size() >= 2) {
            nombres.set(1, "Ana");
        } else {
            System.out.println("No se puede cambiar el nombre.");
        }


        for (String nombre : nombres) {
            System.out.println(nombre);
        }
    }
}


