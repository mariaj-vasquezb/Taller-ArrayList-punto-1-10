package com.example;

import java.util.ArrayList;

public class VerificarNombreEnArrayList {
    public static void main(String[] args) {
        ArrayList<String> nombres = new ArrayList<String>();

        
        nombres.add("Sara");
        nombres.add("Valentina");
        nombres.add("Pedro");
        nombres.add("Luis");

        
        String verificarNombre = "Carlos";

        
        if (nombres.contains(verificarNombre)) {
            System.out.println("El nombre 'Carlos' está presente en la lista.");
        } else {
            System.out.println("El nombre 'Carlos' no está presente en la lista.");
        }
    }
}

