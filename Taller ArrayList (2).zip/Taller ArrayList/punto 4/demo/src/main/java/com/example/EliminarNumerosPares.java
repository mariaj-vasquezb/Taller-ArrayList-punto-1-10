package com.example;

import java.util.ArrayList;

public class EliminarNumerosPares {
    public static void main(String[] args) {
        ArrayList<Integer> numeros = new ArrayList<Integer>();

        numeros.add(10);
        numeros.add(5);
        numeros.add(8);
        numeros.add(17);
        numeros.add(12);
        numeros.add(25);

        
        numeros.removeIf(numero -> numero % 2 == 0);


        for (int numero : numeros) {
            System.out.println(numero);
        }
    }
}

