package com.example;

import java.util.ArrayList;

public class Comprobar {
    public static void main(String[] args) {
        
        ArrayList<String> miArrayList = new ArrayList<String>();

        
        if (miArrayList.isEmpty()) {
            System.out.println("El ArrayList está vacío.");
        } else {
            System.out.println("El ArrayList no está vacío.");
        }
    }
}
